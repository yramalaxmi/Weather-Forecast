// ====================== BACKEND (Node.js/Express) ======================
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const { createServer } = require('http');
const { Server } = require('socket.io');

// Initialize Express app
const app = express();
const server = createServer(app);
const io = new Server(server);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Mock database for demonstration
const weatherData = {
  "Delhi": require('./mock-delhi-weather.json'),
  "Mumbai": require('./mock-mumbai-weather.json')
};

// Weather API Routes
app.get('/api/weather', async (req, res) => {
  const { location } = req.query;
  
  try {
    // In a real app, replace this with actual API call:
    // const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=YOUR_API_KEY`);
    
    // Mock response for demo:
    const data = weatherData[location] || {
      name: location,
      main: { temp: 28 + Math.floor(Math.random() * 10), humidity: 40 + Math.floor(Math.random() * 30) },
      weather: [{ main: "Sunny", icon: "01d" }],
      wind: { speed: 5 + Math.random() * 5 }
    };
    
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  startFrontend(); // Launch React frontend after backend starts
});

// ====================== FRONTEND (React) ======================
function startFrontend() {
  const fs = require('fs');
  const { exec } = require('child_process');
  
  // Create minimal React app structure
  if (!fs.existsSync('public')) {
    fs.mkdirSync('public');
  }
  
  // HTML entry point
  fs.writeFileSync('public/index.html', `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weather App</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
    .app { max-width: 800px; margin: 0 auto; }
    .weather-card { border: 1px solid #ddd; padding: 20px; border-radius: 8px; margin-top: 20px; }
    input { padding: 10px; width: 300px; }
    button { padding: 10px 15px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <script type="text/babel" src="/app.js"></script>
</body>
</html>
  `);

  // React app
  fs.writeFileSync('public/app.js', `
const { useState, useEffect } = React;

function App() {
  const [location, setLocation] = useState('');
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchWeather = async () => {
    setLoading(true);
    try {
      const response = await fetch(\`/api/weather?location=\${location}\`);
      const data = await response.json();
      setWeather(data);
    } catch (error) {
      console.error("Error:", error);
    }
    setLoading(false);
  };

  return (
    <div className="app">
      <h1>Weather App</h1>
      <div>
        <input 
          type="text" 
          value={location} 
          onChange={(e) => setLocation(e.target.value)} 
          placeholder="Enter city name"
        />
        <button onClick={fetchWeather} disabled={loading}>
          {loading ? 'Loading...' : 'Get Weather'}
        </button>
      </div>
      
      {weather && (
        <div className="weather-card">
          <h2>{weather.name}</h2>
          <p>Temperature: {weather.main?.temp}°C</p>
          <p>Humidity: {weather.main?.humidity}%</p>
          <p>Conditions: {weather.weather?.[0]?.main}</p>
          <p>Wind Speed: {weather.wind?.speed} m/s</p>
        </div>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
  `);

  console.log('\nFrontend ready! Access at: http://localhost:5000');
}

// ====================== MOCK DATA ======================
// This would normally be in separate JSON files
const mockData = {
  "mock-delhi-weather.json": {
    "name": "Delhi",
    "main": { "temp": 32, "humidity": 45 },
    "weather": [{ "main": "Haze", "icon": "50d" }],
    "wind": { "speed": 3.5 }
  },
  "mock-mumbai-weather.json": {
    "name": "Mumbai",
    "main": { "temp": 28, "humidity": 75 },
    "weather": [{ "main": "Cloudy", "icon": "03d" }],
    "wind": { "speed": 5.2 }
  }
};

// Create mock data files if they don't exist
const fs = require('fs');
Object.entries(mockData).forEach(([filename, data]) => {
  if (!fs.existsSync(filename)) {
    fs.writeFileSync(filename, JSON.stringify(data, null, 2));
  }
});