
import React, { useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

type AnimationType = 'fade' | 'slide-up' | 'slide-down' | 'scale' | 'blur';

interface AnimatedTransitionProps {
  children: React.ReactNode;
  show: boolean;
  animation?: AnimationType;
  duration?: number;
  delay?: number;
  className?: string;
}

const AnimatedTransition: React.FC<AnimatedTransitionProps> = ({
  children,
  show,
  animation = 'fade',
  duration = 300,
  delay = 0,
  className
}) => {
  const nodeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = nodeRef.current;
    if (!element) return;
    
    if (show) {
      element.style.display = 'block';
      setTimeout(() => {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0) scale(1)';
        element.style.filter = 'blur(0)';
      }, 10);
    } else {
      element.style.opacity = '0';
      if (animation.includes('slide-up')) {
        element.style.transform = 'translateY(20px) scale(1)';
      } else if (animation.includes('slide-down')) {
        element.style.transform = 'translateY(-20px) scale(1)';
      } else if (animation.includes('scale')) {
        element.style.transform = 'translateY(0) scale(0.95)';
      } else if (animation.includes('blur')) {
        element.style.filter = 'blur(8px)';
      }
      
      setTimeout(() => {
        element.style.display = 'none';
      }, duration);
    }
  }, [show, animation, duration]);

  const getAnimationClass = () => {
    switch (animation) {
      case 'fade':
        return 'opacity-0';
      case 'slide-up':
        return 'opacity-0 translate-y-5';
      case 'slide-down':
        return 'opacity-0 -translate-y-5';
      case 'scale':
        return 'opacity-0 scale-95';
      case 'blur':
        return 'opacity-0 blur-[8px]';
      default:
        return 'opacity-0';
    }
  };

  return (
    <div
      ref={nodeRef}
      className={cn(
        getAnimationClass(),
        className
      )}
      style={{
        display: show ? 'block' : 'none',
        transition: `opacity ${duration}ms ease-in-out, transform ${duration}ms ease-in-out, filter ${duration}ms ease-in-out`,
        transitionDelay: `${delay}ms`
      }}
    >
      {children}
    </div>
  );
};

export default AnimatedTransition;
