
import React from 'react';
import { MapPin } from 'lucide-react';
import { WeatherLocation } from '@/types/weather';
import { cn } from '@/lib/utils';

interface LocationItemProps {
  location: WeatherLocation;
  onClick: () => void;
  isActive?: boolean;
}

const LocationItem: React.FC<LocationItemProps> = ({ 
  location, 
  onClick,
  isActive = false
}) => {
  const locationName = location.name;
  const countryName = location.country;
  const stateName = location.state;

  const fullLocation = [
    locationName,
    stateName,
    countryName
  ].filter(Boolean).join(', ');

  return (
    <div 
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg transition-all cursor-pointer hover:bg-primary/5",
        "border border-transparent",
        isActive && "border-primary/20 bg-primary/5"
      )}
      onClick={onClick}
    >
      <div className="p-2 rounded-full bg-primary/10 text-primary">
        <MapPin size={16} className="animate-pulse-slow" />
      </div>
      <div className="flex-1 overflow-hidden">
        <h4 className="text-sm font-medium truncate">{locationName}</h4>
        <p className="text-xs text-muted-foreground truncate">
          {stateName ? `${stateName}, ${countryName}` : countryName}
        </p>
      </div>
    </div>
  );
};

export default LocationItem;
