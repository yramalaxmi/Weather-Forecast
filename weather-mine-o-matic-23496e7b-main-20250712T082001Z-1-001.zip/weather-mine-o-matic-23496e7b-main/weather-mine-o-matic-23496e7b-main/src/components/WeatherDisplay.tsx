
import React from 'react';
import { 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  CloudDrizzle, 
  CloudLightning, 
  Sun, 
  Droplets, 
  Wind, 
  Thermometer, 
  Loader2
} from 'lucide-react';
import { CurrentWeather } from '@/types/weather';
import { cn } from '@/lib/utils';
import AnimatedTransition from './AnimatedTransition';

interface WeatherDisplayProps {
  weather: CurrentWeather | undefined;
  isLoading: boolean;
}

const WeatherDisplay: React.FC<WeatherDisplayProps> = ({ weather, isLoading }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <Loader2 size={48} className="animate-spin text-primary mb-4" />
        <p className="text-muted-foreground animate-pulse">Loading weather data...</p>
      </div>
    );
  }

  if (!weather) return null;

  const getWeatherIcon = (weatherId: number) => {
    // Based on OpenWeatherMap weather condition codes
    // https://openweathermap.org/weather-conditions
    if (weatherId >= 200 && weatherId < 300) {
      return <CloudLightning className="w-20 h-20 text-weather-thunderstorm" />;
    } else if (weatherId >= 300 && weatherId < 400) {
      return <CloudDrizzle className="w-20 h-20 text-weather-drizzle" />;
    } else if (weatherId >= 500 && weatherId < 600) {
      return <CloudRain className="w-20 h-20 text-weather-rain" />;
    } else if (weatherId >= 600 && weatherId < 700) {
      return <CloudSnow className="w-20 h-20 text-weather-snow" />;
    } else if (weatherId >= 700 && weatherId < 800) {
      return <Cloud className="w-20 h-20 text-weather-mist" />;
    } else if (weatherId === 800) {
      return <Sun className="w-20 h-20 text-weather-clear" />;
    } else {
      return <Cloud className="w-20 h-20 text-weather-clouds" />;
    }
  };

  const mainWeatherId = weather.weather[0]?.id || 800;
  const mainWeatherDescription = weather.weather[0]?.description || 'Clear sky';
  const temp = Math.round(weather.main.temp);
  const feelsLike = Math.round(weather.main.feels_like);
  const humidity = weather.main.humidity;
  const windSpeed = Math.round(weather.wind.speed * 3.6); // Convert m/s to km/h

  // Function to get background color based on weather
  const getWeatherClass = (weatherId: number): string => {
    if (weatherId >= 200 && weatherId < 300) {
      return 'bg-gradient-to-br from-weather-thunderstorm/5 to-weather-thunderstorm/20';
    } else if (weatherId >= 300 && weatherId < 400) {
      return 'bg-gradient-to-br from-weather-drizzle/5 to-weather-drizzle/20';
    } else if (weatherId >= 500 && weatherId < 600) {
      return 'bg-gradient-to-br from-weather-rain/5 to-weather-rain/20';
    } else if (weatherId >= 600 && weatherId < 700) {
      return 'bg-gradient-to-br from-weather-snow/5 to-weather-snow/20';
    } else if (weatherId >= 700 && weatherId < 800) {
      return 'bg-gradient-to-br from-weather-mist/5 to-weather-mist/20';
    } else if (weatherId === 800) {
      return 'bg-gradient-to-br from-weather-clear/5 to-weather-clear/20';
    } else {
      return 'bg-gradient-to-br from-weather-clouds/5 to-weather-clouds/20';
    }
  };

  return (
    <AnimatedTransition 
      show={true} 
      animation="scale" 
      className="w-full"
    >
      <div className={cn(
        "overflow-hidden rounded-2xl shadow-lg transition-all duration-300",
        "border border-white/10 backdrop-blur-sm",
        getWeatherClass(mainWeatherId)
      )}>
        <div className="p-8">
          <div className="flex flex-col md:flex-row items-center justify-between mb-6">
            <div className="flex flex-col items-center md:items-start space-y-1 mb-4 md:mb-0">
              <h3 className="text-lg font-medium text-foreground/80">{weather.name}</h3>
              <p className="text-sm text-muted-foreground">{weather.sys.country}</p>
            </div>
            <div className="flex flex-row items-center">
              {getWeatherIcon(mainWeatherId)}
              <div className="ml-4">
                <h2 className="text-5xl font-semibold">{temp}°C</h2>
                <p className="text-sm text-muted-foreground capitalize">{mainWeatherDescription}</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-8">
            <div className="flex flex-col items-center p-4 rounded-xl bg-white/10 border border-white/5">
              <Thermometer size={20} className="text-primary mb-2" />
              <p className="text-xs text-muted-foreground mb-1">Feels Like</p>
              <p className="text-lg font-medium">{feelsLike}°C</p>
            </div>
            
            <div className="flex flex-col items-center p-4 rounded-xl bg-white/10 border border-white/5">
              <Droplets size={20} className="text-blue-500 mb-2" />
              <p className="text-xs text-muted-foreground mb-1">Humidity</p>
              <p className="text-lg font-medium">{humidity}%</p>
            </div>
            
            <div className="flex flex-col items-center p-4 rounded-xl bg-white/10 border border-white/5">
              <Wind size={20} className="text-gray-500 mb-2" />
              <p className="text-xs text-muted-foreground mb-1">Wind</p>
              <p className="text-lg font-medium">{windSpeed} km/h</p>
            </div>
          </div>
        </div>
      </div>
    </AnimatedTransition>
  );
};

export default WeatherDisplay;
