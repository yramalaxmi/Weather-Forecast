
import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Loader2 } from 'lucide-react';
import { WeatherLocation } from '@/types/weather';
import LocationItem from './LocationItem';
import { cn } from '@/lib/utils';
import AnimatedTransition from './AnimatedTransition';

interface SearchBarProps {
  onSearch: (term: string) => void;
  onSelectLocation: (location: WeatherLocation) => void;
  locations: WeatherLocation[];
  isLoading: boolean;
  selectedLocation: WeatherLocation | null;
}

const SearchBar: React.FC<SearchBarProps> = ({
  onSearch,
  onSelectLocation,
  locations,
  isLoading,
  selectedLocation
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    
    if (value.length > 2) {
      onSearch(value);
    }
  };

  const handleClearInput = () => {
    setInputValue('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleSelectLocation = (location: WeatherLocation) => {
    onSelectLocation(location);
    setInputValue('');
    setIsFocused(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        resultsRef.current && 
        !resultsRef.current.contains(event.target as Node) &&
        inputRef.current && 
        !inputRef.current.contains(event.target as Node)
      ) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const showResults = isFocused && inputValue.length > 2;

  return (
    <div className="relative w-full max-w-lg mx-auto">
      <div className={cn(
        "relative flex items-center overflow-hidden transition-all duration-300",
        "bg-background border rounded-2xl",
        isFocused 
          ? "shadow-lg ring-2 ring-primary/20" 
          : "shadow"
      )}>
        <div className="flex items-center justify-center w-12 text-muted-foreground">
          <Search size={18} />
        </div>
        
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onFocus={() => setIsFocused(true)}
          placeholder="Search for a location..."
          className="w-full py-4 px-0 bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground/70"
        />
        
        {isLoading && (
          <div className="w-12 flex items-center justify-center text-muted-foreground">
            <Loader2 size={18} className="animate-spin" />
          </div>
        )}
        
        {inputValue && !isLoading && (
          <button 
            onClick={handleClearInput}
            className="w-12 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={18} />
          </button>
        )}
      </div>

      <AnimatedTransition
        show={showResults}
        animation="slide-down"
        className="absolute left-0 right-0 mt-2 z-50 bg-background border rounded-lg shadow-xl max-h-[320px] overflow-y-auto"
      >
        <div ref={resultsRef} className="p-2">
          {locations.length > 0 ? (
            locations.map((location, index) => (
              <LocationItem
                key={`${location.name}-${location.lat}-${location.lon}-${index}`}
                location={location}
                onClick={() => handleSelectLocation(location)}
                isActive={
                  selectedLocation?.lat === location.lat && 
                  selectedLocation?.lon === location.lon
                }
              />
            ))
          ) : (
            <div className="p-4 text-center text-muted-foreground text-sm">
              {inputValue.length > 2 ? 'No locations found' : 'Type at least 3 characters to search'}
            </div>
          )}
        </div>
      </AnimatedTransition>
    </div>
  );
};

export default SearchBar;
