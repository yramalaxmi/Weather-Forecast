
import React, { useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  ResponsiveContainer, 
  Tooltip,
  CartesianGrid 
} from 'recharts';
import { WeatherForecastResponse } from '@/types/weather';
import { Loader2, Calendar } from 'lucide-react';
import AnimatedTransition from './AnimatedTransition';
import { cn } from '@/lib/utils';

interface WeatherHistoryProps {
  forecastData: WeatherForecastResponse | undefined;
  isLoading: boolean;
}

const WeatherHistory: React.FC<WeatherHistoryProps> = ({ forecastData, isLoading }) => {
  const chartData = useMemo(() => {
    if (!forecastData) return [];
    
    return forecastData.list.map(item => {
      const date = new Date(item.dt * 1000);
      return {
        time: `${date.getHours()}:00`,
        date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        temp: Math.round(item.main.temp),
        humidity: item.main.humidity,
        description: item.weather[0].description,
        weatherId: item.weather[0].id
      };
    });
  }, [forecastData]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <Loader2 size={48} className="animate-spin text-primary mb-4" />
        <p className="text-muted-foreground animate-pulse">Loading forecast data...</p>
      </div>
    );
  }

  if (!forecastData || chartData.length === 0) return null;

  const formatDay = (dateStr: string) => {
    return dateStr.split(',')[0]; // Get just the weekday
  };

  // Group forecast data by date
  const groupedByDate = chartData.reduce((acc, curr) => {
    const day = curr.date.split(',')[0];
    if (!acc[day]) {
      acc[day] = [];
    }
    acc[day].push(curr);
    return acc;
  }, {} as Record<string, typeof chartData>);

  return (
    <AnimatedTransition 
      show={true} 
      animation="slide-up" 
      delay={200} 
      className="w-full mt-8"
    >
      <div className="rounded-2xl border shadow-lg overflow-hidden bg-background p-6">
        <div className="flex items-center mb-6">
          <Calendar className="mr-2 text-primary" size={20} />
          <h3 className="text-xl font-medium">5-Day Forecast</h3>
        </div>

        <div className="space-y-8">
          {Object.entries(groupedByDate).map(([day, dayData], index) => {
            // Calculate min and max temperatures for the day
            const temperatures = dayData.map(d => d.temp);
            const minTemp = Math.min(...temperatures);
            const maxTemp = Math.max(...temperatures);
            
            // Get the most common weather condition for the day
            const weatherCounts = dayData.reduce((acc, curr) => {
              const id = curr.weatherId;
              acc[id] = (acc[id] || 0) + 1;
              return acc;
            }, {} as Record<number, number>);
            
            const dominantWeatherId = Object.entries(weatherCounts)
              .sort((a, b) => b[1] - a[1])[0][0];
              
            // Function to get color based on weather
            const getWeatherColor = (weatherId: number): string => {
              if (weatherId >= 200 && weatherId < 300) return '#3D348B';
              if (weatherId >= 300 && weatherId < 400) return '#829CBC';
              if (weatherId >= 500 && weatherId < 600) return '#577590';
              if (weatherId >= 600 && weatherId < 700) return '#E9ECEF';
              if (weatherId >= 700 && weatherId < 800) return '#CED4DA';
              if (weatherId === 800) return '#4CC9F0';
              return '#ADB5BD';
            };
            
            const chartColor = getWeatherColor(parseInt(dominantWeatherId));
            
            return (
              <div key={day} className={cn(
                "p-4 rounded-xl",
                index === 0 ? "bg-primary/5" : "bg-secondary"
              )}>
                <div className="flex justify-between items-center mb-4">
                  <h4 className="font-medium">{day}</h4>
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-muted-foreground">
                      Min: <span className="font-medium text-foreground">{minTemp}°C</span>
                    </span>
                    <span className="text-sm text-muted-foreground">
                      Max: <span className="font-medium text-foreground">{maxTemp}°C</span>
                    </span>
                  </div>
                </div>
                
                <div className="h-36">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={dayData}
                      margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                    >
                      <defs>
                        <linearGradient id={`color${index}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={chartColor} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={chartColor} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis
                        dataKey="time"
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis 
                        hide 
                        domain={[(dataMin: number) => Math.floor(dataMin - 2), (dataMax: number) => Math.ceil(dataMax + 2)]} 
                      />
                      <Tooltip
                        contentStyle={{
                          background: 'rgba(255, 255, 255, 0.8)',
                          border: 'none',
                          borderRadius: '8px',
                          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                          backdropFilter: 'blur(8px)'
                        }}
                        formatter={(value: number) => [`${value}°C`, 'Temperature']}
                        labelFormatter={(label) => `Time: ${label}`}
                      />
                      <Area
                        type="monotone"
                        dataKey="temp"
                        stroke={chartColor}
                        strokeWidth={2}
                        fill={`url(#color${index})`}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AnimatedTransition>
  );
};

export default WeatherHistory;
