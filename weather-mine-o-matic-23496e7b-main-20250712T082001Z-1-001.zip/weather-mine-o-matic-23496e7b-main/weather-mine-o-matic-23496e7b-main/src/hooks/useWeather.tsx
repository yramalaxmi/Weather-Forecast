
import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  WeatherLocation, 
  CurrentWeather,
  WeatherForecastResponse,
  LoadingStatus
} from '@/types/weather';
import { toast } from "sonner";

// API key for OpenWeatherMap - in production, this should be in an environment variable
const API_KEY = "fd3150a661c1ddc90d3aefdec0400de4"; // Free tier OpenWeatherMap API key

export const useWeather = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<WeatherLocation | null>(null);
  const [searchStatus, setSearchStatus] = useState<LoadingStatus>('idle');

  const searchLocations = useCallback(async (query: string): Promise<WeatherLocation[]> => {
    if (!query.trim()) return [];
    
    setSearchStatus('loading');
    try {
      const response = await fetch(
        `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(query)}&limit=5&appid=${API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();
      setSearchStatus('succeeded');
      return data;
    } catch (error) {
      setSearchStatus('failed');
      toast.error("Failed to search locations. Please try again.");
      console.error('Error searching locations:', error);
      return [];
    }
  }, []);

  const { data: locations = [], isLoading: isSearching } = useQuery({
    queryKey: ['locations', searchTerm],
    queryFn: () => searchLocations(searchTerm),
    enabled: searchTerm.length > 2,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: currentWeather, isLoading: isLoadingCurrent } = useQuery({
    queryKey: ['currentWeather', selectedLocation?.lat, selectedLocation?.lon],
    queryFn: async (): Promise<CurrentWeather> => {
      if (!selectedLocation) throw new Error('No location selected');
      
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${selectedLocation.lat}&lon=${selectedLocation.lon}&units=metric&appid=${API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch current weather');
      }
      
      return response.json();
    },
    enabled: !!selectedLocation,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: forecastData, isLoading: isLoadingForecast } = useQuery({
    queryKey: ['forecast', selectedLocation?.lat, selectedLocation?.lon],
    queryFn: async (): Promise<WeatherForecastResponse> => {
      if (!selectedLocation) throw new Error('No location selected');
      
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${selectedLocation.lat}&lon=${selectedLocation.lon}&units=metric&appid=${API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch weather forecast');
      }
      
      return response.json();
    },
    enabled: !!selectedLocation,
    staleTime: 30 * 60 * 1000, // 30 minutes
  });

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handleSelectLocation = (location: WeatherLocation) => {
    setSelectedLocation(location);
    setSearchTerm('');
  };

  return {
    searchTerm,
    locations,
    selectedLocation,
    currentWeather,
    forecastData,
    isSearching,
    isLoadingCurrent,
    isLoadingForecast,
    searchStatus,
    handleSearch,
    handleSelectLocation,
  };
};
