
import React, { useState, useEffect } from 'react';
import SearchBar from '@/components/SearchBar';
import WeatherDisplay from '@/components/WeatherDisplay';
import WeatherHistory from '@/components/WeatherHistory';
import { useWeather } from '@/hooks/useWeather';
import { Toaster } from "sonner";
import { cn } from '@/lib/utils';

const Index = () => {
  const [mounted, setMounted] = useState(false);
  const {
    searchTerm,
    locations,
    selectedLocation,
    currentWeather,
    forecastData,
    isSearching,
    isLoadingCurrent,
    isLoadingForecast,
    handleSearch,
    handleSelectLocation,
  } = useWeather();

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  const getBackgroundGradient = () => {
    const weatherId = currentWeather?.weather[0]?.id;
    
    if (!weatherId) return "bg-gradient-to-br from-blue-50 to-gray-100";
    
    if (weatherId >= 200 && weatherId < 300) {
      return "bg-gradient-to-br from-indigo-50 to-purple-100";
    } else if (weatherId >= 300 && weatherId < 400) {
      return "bg-gradient-to-br from-blue-50 to-gray-100";
    } else if (weatherId >= 500 && weatherId < 600) {
      return "bg-gradient-to-br from-blue-50 to-gray-200";
    } else if (weatherId >= 600 && weatherId < 700) {
      return "bg-gradient-to-br from-blue-50 to-gray-50";
    } else if (weatherId >= 700 && weatherId < 800) {
      return "bg-gradient-to-br from-gray-50 to-gray-200";
    } else if (weatherId === 800) {
      return "bg-gradient-to-br from-blue-50 to-sky-100";
    } else {
      return "bg-gradient-to-br from-gray-50 to-blue-100";
    }
  };

  return (
    <div className={cn(
      "min-h-screen transition-all duration-700",
      getBackgroundGradient()
    )}>
      <div className="max-w-5xl mx-auto px-4 py-8 md:py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-light tracking-tight text-gray-900 mb-2">
            <span className="font-normal">Weather</span>
            <span className="text-primary font-medium">Forecast</span>
          </h1>
          <p className="text-gray-600 max-w-md mx-auto">
            Search for a location to view current weather conditions and forecast data
          </p>
        </div>
        
        <div className="mb-8">
          <SearchBar
            onSearch={handleSearch}
            onSelectLocation={handleSelectLocation}
            locations={locations}
            isLoading={isSearching}
            selectedLocation={selectedLocation}
          />
        </div>
        
        {selectedLocation ? (
          <div className="space-y-8 animate-in">
            <WeatherDisplay 
              weather={currentWeather} 
              isLoading={isLoadingCurrent} 
            />
            
            <WeatherHistory 
              forecastData={forecastData} 
              isLoading={isLoadingForecast} 
            />
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center space-y-4">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="w-12 h-12 text-primary" 
                fill="none"
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={1.5} 
                  d="M19.9 18.9c.8-.8.8-2.1 0-2.8-.8-.8-2.1-.8-2.8 0-.8.8-.8 2.1 0 2.8.7.7 2 .7 2.8 0zm-16-16c.8-.8.8-2.1 0-2.8-.8-.8-2.1-.8-2.8 0-.8.8-.8 2.1 0 2.8.7.7 2 .7 2.8 0zm16 0c.8-.8.8-2.1 0-2.8-.8-.8-2.1-.8-2.8 0-.8.8-.8 2.1 0 2.8.7.7 2 .7 2.8 0zm-16 16c.8-.8.8-2.1 0-2.8-.8-.8-2.1-.8-2.8 0-.8.8-.8 2.1 0 2.8.7.7 2 .7 2.8 0z"
                />
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={1.5} 
                  d="M12 6.9c-2.5 0-4.6 2-4.6 4.6 0 .3 0 .7.1 1-.2 0-.4-.1-.7-.1-2.5 0-4.6 2-4.6 4.6s2 4.6 4.6 4.6h9.8c3.2 0 5.7-2.6 5.7-5.7 0-3-2.3-5.4-5.2-5.7-.2-1.9-1.8-3.3-3.7-3.3h-1.4z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-700">No Location Selected</h3>
            <p className="text-gray-500 max-w-md">
              Search for a city, region, or country to view the current weather and forecast
            </p>
          </div>
        )}
      </div>
      <Toaster position="bottom-center" />
    </div>
  );
};

export default Index;
